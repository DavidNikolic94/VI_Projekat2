import sys
from cx_Freeze import setup, Executable

setup(
    name="Object Detection",
    version="1.0",
    description="Software that detects objects in real time",
    executables=[Executable("object_detection.py")],
    py_modules=[],
)
